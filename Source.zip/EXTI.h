/*
 * ECE 153B - Summer 2020
 *
 * Name(s):
 * Section:
 * Lab: 1B
 */

#ifndef __STM32L476G_DISCOVERY_EXTI_H
#define __STM32L476G_DISCOVERY_EXTI_H

#include "stm32l476xx.h"

void EXTI_Init(void);

#endif
