#ifndef __STM32L476G_DISCOVERY_DFSDM_H
#define __STM32L476G_DISCOVERY_DFSDM_H

void DFSDM_Init(void);
void GPIO_Init(void);

#endif 